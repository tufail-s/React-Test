import React from 'react';

const ProgressBar = ({ value, limit, isActive, onPercentageChange }) => {
  const percentage = (value / limit) * 100;

  
  onPercentageChange(percentage);

    const barStyle = {
    width: `${Math.min(percentage, 100)}%`, 
    backgroundColor: percentage > 100 ? 'red' : 'green',
  };

  return (
    <div className={`progress-bar-container ${isActive ? 'active' : ''}`}>
      <div className="progress-bar" style={barStyle}>
        <span className="usage">{`${percentage.toFixed(2)}%`}</span>
      </div>
    </div>
  );
};

export default ProgressBar;
