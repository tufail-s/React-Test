import React, { useState, useEffect } from 'react';
import ProgressBar from './ProgressBar';
import './styles.css';

const App = () => {
  const [bars, setBars] = useState([50, 30, 70]);
  const [buttons, setButtons] = useState([25,10, -10, -25]);
  const [selectedBar, setSelectedBar] = useState(0);
  const [percentage, setPercentage] = useState(0);

  const handleButtonClick = (value) => {
    const updatedBars = [...bars];
    updatedBars[selectedBar] += value;
    updatedBars[selectedBar] = Math.max(0, Math.min(updatedBars[selectedBar], 500));
    setBars(updatedBars);
  };

  const handleSelectChange = (event) => {
    setSelectedBar(parseInt(event.target.value, 10));
  };

  const handlePercentageChange = (newPercentage) => {
    setPercentage(newPercentage);
  };

  return (
    <div className="App">
      <h1>Progress Bars Demo</h1>
        {bars.map((bar, index) => (
        <ProgressBar
          key={index}
          value={bar}
          limit={100}
          isActive={index === selectedBar}
          onPercentageChange={handlePercentageChange}
        />
      ))}
      <div className="controls">
       <select value={selectedBar} onChange={handleSelectChange}>
        {bars.map((_, index) => (
          <option key={index} value={index}>
            Progress Bar {index + 1}
          </option>
        ))}
      </select>
        {buttons.map((button, index) => (
          <button key={index} onClick={() => handleButtonClick(button)}>
            {button > 0 ? `+${button}` : button}
          </button>
        ))}
      </div>
    </div>
  );
};

export default App;
